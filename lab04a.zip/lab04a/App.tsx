import Bai1 from './components/Bai1'
import Bai2 from './components/Bai2'

export default function App() {
  return (
    // <Bai1></Bai1>
    <Bai2></Bai2>
  );
}
