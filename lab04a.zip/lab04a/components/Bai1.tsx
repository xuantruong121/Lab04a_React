import {
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  Text,
  FlatList,
} from 'react-native';

type Product = {
  id: string;
  shop: string;
  name: string;
  image: string;
};

const images = {
  ca_nau_lau: require('../assets/bai1/ca_nau_lau.png'),
  kho_ga_bo: require('../assets/bai1/ga_bo_toi.png'),
  xe_can_cau: require('../assets/bai1/xa_can_cau.png'),
  do_choi_dang_mo_hinh: require('../assets/bai1/do_choi_dang_mo_hinh.png'),
  lanh_dao: require('../assets/bai1/lanh_dao_gian_don.png'),
  hieu_long_tre_con: require('../assets/bai1/hieu_long_con_tre.png'),
  trump: require('../assets/bai1/trump 1.png'),
};

const DATA: Product[] = [
  {
    id: '1',
    name: 'Ca nấu lẩu, nấu mì mini',
    shop: 'Devang',
    image: images.ca_nau_lau,
  },
  {
    id: '2',
    name: '1KG KHÔ GÀ BƠ TỎI',
    shop: 'LTD Fôd',
    image: images.kho_ga_bo,
  },
  {
    id: '3',
    name: 'Xe cần cẩu đa năng',
    shop: 'Thế giới đồ chơi',
    image: images.xe_can_cau,
  },
  {
    id: '4',
    name: 'Đồ chơi dạng mô hình',
    shop: 'Thế giới đồ chơi',
    image: images.do_choi_dang_mo_hinh,
  },
  {
    id: '5',
    name: 'Lãnh đạo giản đơn',
    shop: 'Minh Long Book',
    image: images.lanh_dao,
  },
  {
    id: '6',
    name: 'Hiểu lòng trẻ con',
    shop: 'Minh Long Book',
    image: images.hieu_long_tre_con,
  },
  {
    id: '7',
    name: 'Donal Trump thiên tài lãnh đạo',
    shop: 'Minh Long Book',
    image: images.trump,
  },
];

export default function Bai1() {
  const renderItem = ({ item }: { item: Product }) => (
    <View style={styles.itemContainer}>
      <Image source={item.image} style={styles.image} />
      <View style={styles.infoContainer}>
        <Text style={styles.name} numberOfLines={1}>
          {item.name}
        </Text>
        <Text style={styles.shop}>{item.shop}</Text>
      </View>
      <TouchableOpacity style={styles.chatButton}>
        <Text style={styles.chatText}>Chat</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity>
          <Image
            source={require('../assets/bai1/ant-design_arrow-left-outlined.png')}
          />
        </TouchableOpacity>
        <Text style={styles.title}>Chat</Text>
        <TouchableOpacity>
          <Image source={require('../assets/bai1/bi_cart-check.png')} />
        </TouchableOpacity>
      </View>
      <Text style={styles.contentText}>
        Bạn có thắc mắc với sản phẩm vừa xem. Đừng ngại chat với shop!
      </Text>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
      <View style={styles.footer}>
        <TouchableOpacity>
          <Image source={require('../assets/bai1/Group 10.png')} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={require('../assets/bai1/Vector.png')} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={require('../assets/bai1/Vector 1 (Stroke).png')} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E5E5E5',
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    padding: 10,
    marginBottom: 8,
    borderRadius: 8,
  },
  image: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
    marginRight: 10,
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    fontSize: 14,
    fontWeight: '500',
  },
  shop: {
    fontSize: 12,
    color: 'gray',
  },
  chatButton: {
    backgroundColor: 'red',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
  },
  chatText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  contentText: {
    alignItems: 'center',
    padding: 10,
  },
  header: {
    backgroundColor: '#1BA9FF',
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  title: {
    color: 'white',
    alignItems: 'center',
    fontWeight: 'bold',
  },
  footer: {
    backgroundColor: '#1BA9FF',
    flexDirection: 'row',
    height: 50,
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    alignItems: 'center',
  },
});
