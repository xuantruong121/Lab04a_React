import {
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  Text,
  FlatList,
  TextInput,
} from 'react-native';

type Product = {
  id: string;
  name: string;
  price: string;
  discount: string;
  rating: number;
  reviews: number;
  image: string;
};

const images = {
  dau_cam: require('../assets/bai2/daucam 1.png'),
  dau_chuyen_doi: require('../assets/bai2/dauchuyendoi 1.png'),
  dau_chuyen_doi_ps: require('../assets/bai2/dauchuyendoipsps2 1.png'),
  day_nguon: require('../assets/bai2/daynguon 1.png'),
  giac_chuyen: require('../assets/bai2/giacchuyen 1.png'),
  carbusstop: require('../assets/bai2/carbusbtops2 1.png'),
};

const DATA: Product[] = [
  {
    id: '1',
    name: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    discount: '-39%',
    rating: 4,
    reviews: 15,
    image: images.dau_cam,
  },
  {
    id: '2',
    name: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    discount: '-39%',
    rating: 4,
    reviews: 15,
    image: images.carbusstop,
  },
  {
    id: '3',
    name: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    discount: '-39%',
    rating: 4,
    reviews: 15,
    image: images.dau_chuyen_doi,
  },
  {
    id: '4',
    name: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    discount: '-39%',
    rating: 4,
    reviews: 15,
    image: images.dau_chuyen_doi_ps,
  },
  {
    id: '5',
    name: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    discount: '-39%',
    rating: 4,
    reviews: 15,
    image: images.day_nguon,
  },
  {
    id: '6',
    name: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    discount: '-39%',
    rating: 4,
    reviews: 15,
    image: images.giac_chuyen,
  },
];

export default function Bai1() {
  const renderItem = ({ item }: { item: Product }) => (
    <TouchableOpacity style={styles.productCard}>
      <Image source={item.image} style={styles.productImage} />
      <Text style={styles.productName} numberOfLines={2}>
        {item.name}
      </Text>
      <View style={styles.ratingRow}>
        <Text>{'⭐'.repeat(item.rating)}</Text>
        <Text style={styles.reviewText}>({item.reviews})</Text>
      </View>
      <View style={styles.priceRow}>
        <Text style={styles.productPrice}>{item.price}</Text>
        <Text style={styles.discount}>{item.discount}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity>
          <Image
            source={require('../assets/bai2/ant-design_arrow-left-outlined.png')}
          />
        </TouchableOpacity>
        <View style={styles.searchContainer}>
          <Image source={require('../assets/bai2/whh_magnifier.png')} />
          <TextInput
            placeholder="Dây cáp usb"
            style={styles.searchInput}
            placeholderTextColor="#666"
          />
        </View>
        <TouchableOpacity>
          <Image source={require('../assets/bai2/bi_cart-check.png')} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Text style={{ fontWeight: 'bold', color: 'white', fontSize: 20 }}>
            ...
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
      />

      <View style={styles.footer}>
        <TouchableOpacity>
          <Image source={require('../assets/bai2/Group 10.png')} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={require('../assets/bai2/Vector.png')} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={require('../assets/bai2/Vector 1 (Stroke).png')} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E5E5E5',
  },
  header: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E9FFF',
    height: 50,
    paddingHorizontal: 15,
  },
  searchContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 5,
    alignItems: 'center',
    paddingHorizontal: 8,
    marginRight: 8,
  },
  searchInput: { flex: 1, fontSize: 14, paddingVertical: 6 },
  productCard: {
    width: '48%',
    backgroundColor: '#f9f9f9',
    borderRadius: 6,
    padding: 6,
    margin: 10,
  },
  productImage: { width: '100%' , height: 150, borderRadius: 4 },
  productName: { fontSize: 13, marginVertical: 4 },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  productPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
    marginRight: 10,
  },
  ratingRow: { flexDirection: 'row', alignItems: 'center' },
  reviewText: { fontSize: 12, marginLeft: 4 },
  discount: { fontSize: 12, color: 'gray' },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 50,
    backgroundColor: '#1E9FFF',
  },
});
