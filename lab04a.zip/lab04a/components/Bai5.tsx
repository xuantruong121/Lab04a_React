import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
} from "react-native";

interface Photo {
  id: string;
  author: string;
  download_url: string;
}

export default function App() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isGrid, setIsGrid] = useState<boolean>(false);

  useEffect(() => {
    const fetchPhotos = async () => {
      try {
        const response = await fetch(
          "https://picsum.photos/v2/list?limit=20"
        );
        const data = await response.json();
        setPhotos(data);
      } catch (error) {
        console.error("Error fetching photos:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPhotos();
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="blue" />
        <Text>Đang tải dữ liệu...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {/* Tiêu đề */}
      <Text style={styles.title}>Gallery App</Text>
      <Text style={styles.description}>
        Ảnh ngẫu nhiên từ Picsum Photos API.
      </Text>

      {/* Horizontal List cho ảnh nổi bật */}
      <Text style={styles.subtitle}>Ảnh nổi bật</Text>
      <FlatList
        data={photos.slice(0, 5)}
        horizontal
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.featuredCard}>
            <Image source={{ uri: item.download_url }} style={styles.featuredImage} />
            <Text numberOfLines={1} style={styles.imageTitle}>
              {item.author}
            </Text>
          </View>
        )}
      />

      {/* Nút chuyển đổi */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => setIsGrid((prev) => !prev)}
      >
        <Text style={styles.buttonText}>
          {isGrid ? "Chuyển sang ListView" : "Chuyển sang GridView"}
        </Text>
      </TouchableOpacity>

      {/* Danh sách ảnh chính */}
      <FlatList
        data={photos}
        key={isGrid ? "g" : "l"}
        numColumns={isGrid ? 2 : 1}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.card, isGrid && styles.cardGrid]}>
            <Image source={{ uri: item.download_url }} style={styles.image} />
            <Text numberOfLines={1} style={styles.imageTitle}>
              {item.author}
            </Text>
          </View>
        )}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 12,
    backgroundColor: "#fff",
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 6,
  },
  description: {
    fontSize: 14,
    marginBottom: 12,
    color: "#333",
  },
  subtitle: {
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 8,
  },
  featuredCard: {
    marginRight: 12,
    alignItems: "center",
    width: 120,
  },
  featuredImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginBottom: 6,
  },
  button: {
    marginVertical: 12,
    padding: 10,
    borderRadius: 8,
    backgroundColor: "#007bff",
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "600",
  },
  card: {
    flex: 1,
    marginBottom: 12,
    marginRight: 12,
  },
  cardGrid: {
    maxWidth: "48%",
  },
  image: {
    width: "100%",
    height: 180,
    borderRadius: 8,
    marginBottom: 6,
  },
  imageTitle: {
    fontSize: 13,
    color: "#333",
  },
});
